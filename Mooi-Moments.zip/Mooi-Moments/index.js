 

document.querySelector('#redirect')
    .addEventListener('click' , ()=> {
    window.location.href = 'register.html';
});

   
